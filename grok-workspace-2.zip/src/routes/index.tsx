import { createFileRoute } from "@tanstack/react-router";
import { Z5500Deck } from "@/components/deck/z5500-deck";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Z5500Deck />;
}
