import { useCallback, useEffect, useRef, useState } from "react";
import { CHANNELS, EFFECTS, INPUTS, VOLUME_MAX } from "@/lib/deck";
import { Z5500_IR } from "@/lib/ir/codes";
import { transmitIRCode } from "@/lib/ir/transmit";
import { Waveform } from "./waveform";

const HOLD_MS = 170;

export function Z5500Deck() {
  const [power, setPower] = useState(true);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(18);
  const [effectIndex, setEffectIndex] = useState(0);
  const [inputIndex, setInputIndex] = useState(0);
  const [link, setLink] = useState("IR 38 KHZ");
  const [hot, setHot] = useState(false);
  const [txPulse, setTxPulse] = useState(0);

  const volumeRef = useRef(volume);
  const mutedRef = useRef(muted);
  const holdRef = useRef(0);
  const txSerial = useRef(0);
  const mounted = useRef(true);
  volumeRef.current = volume;
  mutedRef.current = muted;

  const effect = EFFECTS[effectIndex] ?? EFFECTS[0];
  const input = INPUTS[inputIndex] ?? INPUTS[0];
  const lit = new Set<string>(effect.channels);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      window.clearInterval(holdRef.current);
    };
  }, []);

  const blast = useCallback((hex: string) => {
    const serial = ++txSerial.current;
    setHot(true);
    setTxPulse((n) => n + 1);
    setLink(`TX ${hex.slice(2).toUpperCase()}`);
    window.setTimeout(() => {
      if (mounted.current && txSerial.current === serial) setHot(false);
    }, 160);
    void transmitIRCode(hex)
      .then(() => {
        window.setTimeout(() => {
          if (mounted.current && txSerial.current === serial) setLink("IR 38 KHZ");
        }, 760);
      })
      .catch(() => {
        if (mounted.current && txSerial.current === serial) setLink("NO EMITTER");
      });
  }, []);

  const changeVolume = useCallback(
    (dir: 1 | -1) => {
      const next = Math.min(VOLUME_MAX, Math.max(0, volumeRef.current + dir));
      volumeRef.current = next;
      setVolume(next);
      if (mutedRef.current) {
        mutedRef.current = false;
        setMuted(false);
      }
      blast(dir > 0 ? Z5500_IR.volumeUp : Z5500_IR.volumeDown);
    },
    [blast],
  );

  const changeVolumeRef = useRef(changeVolume);
  changeVolumeRef.current = changeVolume;

  const stopHold = useCallback(() => {
    window.clearInterval(holdRef.current);
    holdRef.current = 0;
  }, []);

  const startHold = useCallback(
    (dir: 1 | -1) => {
      stopHold();
      changeVolumeRef.current(dir);
      holdRef.current = window.setInterval(() => changeVolumeRef.current(dir), HOLD_MS);
    },
    [stopHold],
  );

  const onPower = useCallback(() => {
    setPower((on) => !on);
    blast(Z5500_IR.power);
  }, [blast]);

  const onMute = useCallback(() => {
    setMuted((value) => {
      mutedRef.current = !value;
      return !value;
    });
    blast(Z5500_IR.mute);
  }, [blast]);

  const onInput = useCallback(() => {
    setInputIndex((index) => (index + 1) % INPUTS.length);
    blast(Z5500_IR.input);
  }, [blast]);

  const onEffect = useCallback(() => {
    setEffectIndex((index) => (index + 1) % EFFECTS.length);
    blast(Z5500_IR.effect);
  }, [blast]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.metaKey || event.ctrlKey || event.altKey) return;
      if (event.key === "ArrowUp") {
        event.preventDefault();
        changeVolume(1);
      } else if (event.key === "ArrowDown") {
        event.preventDefault();
        changeVolume(-1);
      } else if (!event.repeat && event.key.toLowerCase() === "p") onPower();
      else if (!event.repeat && event.key.toLowerCase() === "m") onMute();
      else if (!event.repeat && event.key.toLowerCase() === "i") onInput();
      else if (!event.repeat && event.key.toLowerCase() === "e") onEffect();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [changeVolume, onEffect, onInput, onMute, onPower]);

  const level = (volume / VOLUME_MAX) * 100;

  return (
    <main className="stage">
      <div className="shell">
        <section
          className="deck"
          data-on={power ? "true" : "false"}
          data-muted={muted ? "true" : "false"}
          aria-label="Z-5500 deck"
        >
          <span className="screw screw-a" aria-hidden />
          <span className="screw screw-b" aria-hidden />
          <span className="screw screw-c" aria-hidden />
          <span className="screw screw-d" aria-hidden />

          <header className="deck-top">
            <button
              type="button"
              className="power"
              data-control="power"
              aria-pressed={power}
              onClick={onPower}
            >
              <span className="power-led" aria-hidden />
              <span className="power-label">POWER</span>
            </button>
            <div className="brand">
              <p className="brand-name">Z-5500</p>
              <p className="brand-sub">Digital deck</p>
            </div>
            <div className={`emitter${hot ? " is-hot" : ""}`} aria-hidden>
              <span className="emitter-lens" />
              <span className="emitter-label">IR</span>
            </div>
          </header>

          <div className="glass">
            <Waveform
              power={power}
              muted={muted}
              volume={volume}
              effectId={effect.id}
              txPulse={txPulse}
            />
            <div className="lcd">
              <div className="lcd-figure">
                <span className="lcd-number">{muted ? "MUTE" : String(volume).padStart(2, "0")}</span>
                <span className="lcd-unit">{muted ? "LEVEL HELD" : "LEVEL"}</span>
              </div>
              <div className="lcd-meta">
                <span>{input.label}</span>
                <span>{effect.label}</span>
                <span className="channels">
                  {CHANNELS.map((channel) => (
                    <span key={channel} className={lit.has(channel) ? "is-lit" : undefined}>
                      {channel}
                    </span>
                  ))}
                </span>
              </div>
              <p className="lcd-status" aria-live="polite">
                {link}
              </p>
            </div>
          </div>

          <div className="controls">
            <div className="vol" style={{ ["--level" as string]: String(level) }}>
              <div className="vol-ticks" aria-hidden />
              <div className="vol-arc" aria-hidden />
              <button
                type="button"
                className="vol-hit vol-hit-up"
                data-control="volume-up"
                aria-label="Volume up"
                onPointerDown={(event) => {
                  if (event.button !== 0) return;
                  event.currentTarget.setPointerCapture(event.pointerId);
                  startHold(1);
                }}
                onPointerUp={stopHold}
                onPointerCancel={stopHold}
                onClick={(event) => {
                  if (event.detail === 0) changeVolume(1);
                }}
              >
                VOL +
              </button>
              <button
                type="button"
                className="vol-hit vol-hit-down"
                data-control="volume-down"
                aria-label="Volume down"
                onPointerDown={(event) => {
                  if (event.button !== 0) return;
                  event.currentTarget.setPointerCapture(event.pointerId);
                  startHold(-1);
                }}
                onPointerUp={stopHold}
                onPointerCancel={stopHold}
                onClick={(event) => {
                  if (event.detail === 0) changeVolume(-1);
                }}
              >
                VOL −
              </button>
              <div className="vol-hub" aria-hidden>
                <span className="vol-figure">{String(volume).padStart(2, "0")}</span>
                <span className="vol-caption">LEVEL</span>
              </div>
            </div>

            <div className="side">
              <button
                type="button"
                className="effect"
                data-control="effect"
                aria-label={`Effect control, ${effect.label}`}
                style={{ ["--notch" as string]: `${(effectIndex / EFFECTS.length) * 360}deg` }}
                onClick={onEffect}
              >
                <span className="effect-notch" aria-hidden />
                <span className="effect-kicker">EFFECT</span>
                <span className="effect-name">{effect.short}</span>
              </button>
              <button
                type="button"
                className="key"
                data-control="mute"
                aria-pressed={muted}
                onClick={onMute}
              >
                <span className="key-kicker">MUTE</span>
              </button>
              <button type="button" className="key" data-control="input" onClick={onInput}>
                <span className="key-kicker">INPUT</span>
                <span className="key-value">{input.label}</span>
              </button>
            </div>
          </div>
        </section>
      </div>
      <p className="note">
        Power, volume, mute, input, and effect each send their NEC code to the Android IR blaster.
        A browser can only arm the same 38 kHz burst — the emitter fires on a phone that has one.
      </p>
    </main>
  );
}
