import { useEffect, useRef } from "react";
import { VOLUME_MAX, WAVE_PARTIALS, type EffectId } from "@/lib/deck";

type WaveformProps = {
  power: boolean;
  muted: boolean;
  volume: number;
  effectId: EffectId;
  txPulse: number;
};

const VIEW_W = 800;
const VIEW_H = 176;

export function Waveform({ power, muted, volume, effectId, txPulse }: WaveformProps) {
  const glowRef = useRef<SVGPathElement>(null);
  const coreRef = useRef<SVGPathElement>(null);
  const stateRef = useRef({ power, muted, volume, effectId, txFrames: 0 });
  stateRef.current = { power, muted, volume, effectId, txFrames: stateRef.current.txFrames };

  useEffect(() => {
    stateRef.current.txFrames = 18;
  }, [txPulse]);

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    let raf = 0;
    let stopped = false;

    const draw = () => {
      const { power: on, muted: isMuted, volume: level, effectId: effect, txFrames } =
        stateRef.current;
      const partials = WAVE_PARTIALS[effect];
      const mid = VIEW_H * 0.38;
      const amp = on ? (isMuted ? 0.035 : 0.08 + (level / VOLUME_MAX) * 0.32) * VIEW_H : 0;
      const tx = txFrames / 18;
      let d = "";
      for (let x = 0; x <= VIEW_W; x += 4) {
        const u = x / VIEW_W;
        let y = 0;
        if (on) {
          for (let k = 0; k < partials.length; k += 1) {
            const partial = partials[k] ?? 1;
            y +=
              Math.sin(u * Math.PI * 2 * partial * 1.35 + frame * (0.045 + k * 0.012)) /
              partials.length;
          }
          if (tx > 0) y += Math.sin(u * 70 + frame * 0.8) * tx * 0.55;
        }
        const py = mid + y * amp;
        d += `${x === 0 ? "M" : "L"}${x.toFixed(1)} ${py.toFixed(1)}`;
      }
      glowRef.current?.setAttribute("d", d);
      coreRef.current?.setAttribute("d", d);
      if (stateRef.current.txFrames > 0) stateRef.current.txFrames -= 1;
      if (!media.matches) frame += 1;
    };

    const loop = () => {
      draw();
      if (!stopped) raf = window.requestAnimationFrame(loop);
    };
    loop();

    return () => {
      stopped = true;
      window.cancelAnimationFrame(raf);
    };
  }, []);

  const cols = [1, 2, 3, 4, 5, 6, 7];
  const rows = [1, 2, 3];

  return (
    <svg className="wave" viewBox={`0 0 ${VIEW_W} ${VIEW_H}`} preserveAspectRatio="none" aria-hidden>
      <g className="wave-grid">
        {cols.map((index) => (
          <line key={`c${index}`} x1={(VIEW_W / 8) * index} y1="0" x2={(VIEW_W / 8) * index} y2={VIEW_H} />
        ))}
        {rows.map((index) => (
          <line key={`r${index}`} x1="0" y1={(VIEW_H / 4) * index} x2={VIEW_W} y2={(VIEW_H / 4) * index} />
        ))}
      </g>
      <path ref={glowRef} className="wave-glow" />
      <path ref={coreRef} className="wave-core" />
    </svg>
  );
}
