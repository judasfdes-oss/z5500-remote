export const VOLUME_MAX = 40;

export const EFFECTS = [
  { id: "stereo", label: "STEREO", short: "ST", channels: ["L", "R"] },
  { id: "movie", label: "PLII MOVIE", short: "MOV", channels: ["L", "C", "R", "Ls", "Rs"] },
  { id: "music", label: "PLII MUSIC", short: "MUS", channels: ["L", "C", "R", "Ls", "Rs"] },
  { id: "3d", label: "3D", short: "3D", channels: ["L", "R", "Ls", "Rs"] },
  { id: "direct", label: "5.1 DIRECT", short: "5.1", channels: ["L", "C", "R", "Ls", "Rs", "LFE"] },
] as const;

export const INPUTS = [
  { id: "optical", label: "OPTICAL" },
  { id: "coax", label: "COAX" },
  { id: "direct", label: "DIRECT" },
] as const;

export const CHANNELS = ["L", "C", "R", "Ls", "Rs", "LFE"] as const;

export type EffectId = (typeof EFFECTS)[number]["id"];

/** Partial weights for the on-screen trace. Not audio — just the deck's face. */
export const WAVE_PARTIALS: Record<EffectId, number[]> = {
  stereo: [1, 2],
  movie: [1, 2, 3, 5],
  music: [1, 2.4, 4],
  "3d": [1, 1.5, 3.1, 6],
  direct: [1, 2, 3, 4, 5.2],
};
