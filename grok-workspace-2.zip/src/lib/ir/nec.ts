/** NEC carrier used by Android ConsumerIrManager. */
export const NEC_CARRIER_HZ = 38_000;

const HEADER_MARK = 9_000;
const HEADER_SPACE = 4_500;
const BIT_MARK = 560;
const ZERO_SPACE = 560;
const ONE_SPACE = 1_690;
const STOP_MARK = 560;

export type NecBurst = {
  hex: string;
  frequencyHz: number;
  /** Alternating mark/space durations in microseconds, starting with a mark. */
  pattern: number[];
};

/**
 * Convert a 32-bit NEC word (address, ~address, command, ~command) into the
 * raw timing pattern ConsumerIrManager.transmit expects at 38 kHz.
 * Bytes go out high-byte first; bits within a byte go out LSB first.
 */
export function encodeNec(hexString: string): NecBurst {
  const hex = normalizeHex(hexString);
  const value = Number.parseInt(hex, 16);
  const pattern: number[] = [HEADER_MARK, HEADER_SPACE];

  for (let byteIndex = 3; byteIndex >= 0; byteIndex -= 1) {
    const byte = (value >> (byteIndex * 8)) & 0xff;
    for (let bit = 0; bit < 8; bit += 1) {
      pattern.push(BIT_MARK);
      pattern.push((byte >> bit) & 1 ? ONE_SPACE : ZERO_SPACE);
    }
  }
  pattern.push(STOP_MARK);

  return {
    hex: `0x${hex}`,
    frequencyHz: NEC_CARRIER_HZ,
    pattern,
  };
}

function normalizeHex(hexString: string): string {
  const trimmed = hexString.trim();
  const body = trimmed.replace(/^0x/i, "");
  if (!/^[0-9a-fA-F]{1,8}$/.test(body)) {
    throw new Error(`Not a 32-bit NEC code: ${hexString}`);
  }
  return body.padStart(8, "0").toUpperCase();
}
