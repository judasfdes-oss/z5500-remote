import { encodeNec, type NecBurst } from "./nec.ts";

export type TransmitResult = NecBurst & {
  transport: "ir-blaster" | "preview";
};

type NativeIRBlaster = {
  transmitIRCode: (hexString: string) => Promise<unknown> | unknown;
};

function nativeBlaster(): NativeIRBlaster | null {
  const host = globalThis as {
    NativeModules?: { IRBlasterModule?: NativeIRBlaster };
  };
  const candidate = host.NativeModules?.IRBlasterModule;
  if (!candidate || typeof candidate.transmitIRCode !== "function") return null;
  return candidate;
}

/**
 * JS entry the deck calls. On Android this hits IRBlasterModule.transmitIRCode,
 * which drives ConsumerIrManager. A browser has no emitter, so the same 38 kHz
 * pattern is still built and reported as a preview burst.
 */
export async function transmitIRCode(hexString: string): Promise<TransmitResult> {
  const burst = encodeNec(hexString);
  const native = nativeBlaster();
  if (!native) return { ...burst, transport: "preview" };
  await native.transmitIRCode(hexString);
  return { ...burst, transport: "ir-blaster" };
}
