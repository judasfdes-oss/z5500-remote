import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { Z5500_IR } from "./codes.ts";
import { encodeNec, NEC_CARRIER_HZ } from "./nec.ts";

describe("encodeNec", () => {
  it("builds a 38 kHz NEC frame for the power code", () => {
    const burst = encodeNec(Z5500_IR.power);
    assert.equal(burst.frequencyHz, NEC_CARRIER_HZ);
    assert.equal(burst.frequencyHz, 38000);
    assert.equal(burst.pattern.length, 67);
    assert.deepEqual(burst.pattern.slice(0, 2), [9000, 4500]);
    assert.equal(burst.pattern.at(-1), 560);
    // Address 0x10, LSB first: 0,0,0,0,1,0,0,0
    const spaces = [560, 560, 560, 560, 1690, 560, 560, 560];
    spaces.forEach((space, index) => {
      assert.equal(burst.pattern[2 + index * 2], 560);
      assert.equal(burst.pattern[3 + index * 2], space);
    });
    // ~address 0xEF starts with LSB 1
    assert.equal(burst.pattern[2 + 16], 560);
    assert.equal(burst.pattern[3 + 16], 1690);
  });

  it("accepts every deck code", () => {
    for (const hex of Object.values(Z5500_IR)) {
      const burst = encodeNec(hex);
      assert.equal(burst.pattern.length, 67);
      assert.equal(burst.frequencyHz, 38000);
      assert.equal(burst.hex, hex);
    }
  });

  it("rejects garbage", () => {
    assert.throws(() => encodeNec("nope"), /32-bit NEC/);
  });
});
