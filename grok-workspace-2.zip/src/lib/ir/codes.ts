/** 32-bit NEC words for the Z-5500 deck. Address 0x10. */
export const Z5500_IR = {
  power: "0x10EF58A7",
  volumeUp: "0x10EF708F",
  volumeDown: "0x10EFB04F",
  mute: "0x10EF30CF",
  input: "0x10EF20DF",
  effect: "0x10EF609F",
} as const;

export type DeckControl = keyof typeof Z5500_IR;
