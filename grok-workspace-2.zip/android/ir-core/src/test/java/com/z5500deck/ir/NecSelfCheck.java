package com.z5500deck.ir;

public final class NecSelfCheck {
    private static final String[] CODES = {
        "0x10EF58A7",
        "0x10EF708F",
        "0x10EFB04F",
        "0x10EF30CF",
        "0x10EF20DF",
        "0x10EF609F",
    };

    public static void main(String[] args) {
        if (NecEncoder.CARRIER_HZ != 38000) fail("carrier");
        for (String code : CODES) {
            int[] pattern = NecEncoder.encode(code);
            if (pattern.length != 67) fail(code + " length " + pattern.length);
            if (pattern[0] != 9000 || pattern[1] != 4500 || pattern[66] != 560) fail(code + " frame");
        }
        int[] power = NecEncoder.encode("0x10EF58A7");
        int[] spaces = {560, 560, 560, 560, 1690, 560, 560, 560};
        for (int i = 0; i < spaces.length; i++) {
            if (power[2 + i * 2] != 560 || power[3 + i * 2] != spaces[i]) fail("addr bit " + i);
        }
        if (power[18] != 560 || power[19] != 1690) fail("inverted address");
        try {
            NecEncoder.encode("nope");
            fail("accepted garbage");
        } catch (IllegalArgumentException expected) {
            // codes that are not 32-bit hex must not reach the emitter
        }
        System.out.println("NEC encoder ok");
    }

    private static void fail(String message) {
        throw new AssertionError(message);
    }
}
