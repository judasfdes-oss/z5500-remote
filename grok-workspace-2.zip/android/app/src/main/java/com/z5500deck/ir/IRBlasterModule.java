package com.z5500deck.ir;

import android.content.Context;
import android.hardware.ConsumerIrManager;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

/**
 * Native bridge to the phone's physical IR blaster.
 * JavaScript calls {@code transmitIRCode(hexString)}.
 */
public class IRBlasterModule extends ReactContextBaseJavaModule {
    public static final String NAME = "IRBlasterModule";

    public IRBlasterModule(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @ReactMethod
    public void transmitIRCode(String hexString, Promise promise) {
        try {
            ConsumerIrManager ir =
                    (ConsumerIrManager)
                            getReactApplicationContext().getSystemService(Context.CONSUMER_IR_SERVICE);
            if (ir == null || !ir.hasIrEmitter()) {
                promise.reject("E_NO_IR", "This device has no infrared emitter.");
                return;
            }
            int[] pattern = NecEncoder.encode(hexString);
            ir.transmit(NecEncoder.CARRIER_HZ, pattern);
            promise.resolve(true);
        } catch (IllegalArgumentException error) {
            promise.reject("E_BAD_CODE", error.getMessage(), error);
        } catch (Exception error) {
            promise.reject("E_IR_TX", error.getMessage(), error);
        }
    }
}
