package com.z5500deck.ir;

/**
 * 32-bit NEC words to the alternating mark/space pattern (microseconds)
 * expected by {@code ConsumerIrManager.transmit} at 38 kHz.
 * Bytes are sent high-byte first. Bits inside a byte are sent LSB first.
 */
public final class NecEncoder {
    public static final int CARRIER_HZ = 38_000;

    private static final int HEADER_MARK = 9_000;
    private static final int HEADER_SPACE = 4_500;
    private static final int BIT_MARK = 560;
    private static final int ZERO_SPACE = 560;
    private static final int ONE_SPACE = 1_690;
    private static final int STOP_MARK = 560;

    private NecEncoder() {}

    public static int[] encode(String hexString) {
        long value = parse(hexString);
        int[] pattern = new int[67];
        int index = 0;
        pattern[index++] = HEADER_MARK;
        pattern[index++] = HEADER_SPACE;

        for (int byteIndex = 3; byteIndex >= 0; byteIndex--) {
            int bite = (int) ((value >> (byteIndex * 8)) & 0xFF);
            for (int bit = 0; bit < 8; bit++) {
                pattern[index++] = BIT_MARK;
                pattern[index++] = ((bite >> bit) & 1) == 1 ? ONE_SPACE : ZERO_SPACE;
            }
        }
        pattern[index] = STOP_MARK;
        return pattern;
    }

    private static long parse(String hexString) {
        if (hexString == null) {
            throw new IllegalArgumentException("Not a 32-bit NEC code: null");
        }
        String body = hexString.trim();
        if (body.startsWith("0x") || body.startsWith("0X")) {
            body = body.substring(2);
        }
        if (!body.matches("[0-9a-fA-F]{1,8}")) {
            throw new IllegalArgumentException("Not a 32-bit NEC code: " + hexString);
        }
        return Long.parseLong(body, 16) & 0xFFFFFFFFL;
    }
}
