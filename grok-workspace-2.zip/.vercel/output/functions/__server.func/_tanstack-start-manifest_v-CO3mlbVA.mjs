//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CO3mlbVA.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D8jsU2V5.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D8jsU2V5.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-lFDB8dNu.js"]
	}
} });
//#endregion
export { tsrStartManifest };
