import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-JYBRQ2bs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EFFECTS = [
	{
		id: "stereo",
		label: "STEREO",
		short: "ST",
		channels: ["L", "R"]
	},
	{
		id: "movie",
		label: "PLII MOVIE",
		short: "MOV",
		channels: [
			"L",
			"C",
			"R",
			"Ls",
			"Rs"
		]
	},
	{
		id: "music",
		label: "PLII MUSIC",
		short: "MUS",
		channels: [
			"L",
			"C",
			"R",
			"Ls",
			"Rs"
		]
	},
	{
		id: "3d",
		label: "3D",
		short: "3D",
		channels: [
			"L",
			"R",
			"Ls",
			"Rs"
		]
	},
	{
		id: "direct",
		label: "5.1 DIRECT",
		short: "5.1",
		channels: [
			"L",
			"C",
			"R",
			"Ls",
			"Rs",
			"LFE"
		]
	}
];
var INPUTS = [
	{
		id: "optical",
		label: "OPTICAL"
	},
	{
		id: "coax",
		label: "COAX"
	},
	{
		id: "direct",
		label: "DIRECT"
	}
];
var CHANNELS = [
	"L",
	"C",
	"R",
	"Ls",
	"Rs",
	"LFE"
];
/** Partial weights for the on-screen trace. Not audio — just the deck's face. */
var WAVE_PARTIALS = {
	stereo: [1, 2],
	movie: [
		1,
		2,
		3,
		5
	],
	music: [
		1,
		2.4,
		4
	],
	"3d": [
		1,
		1.5,
		3.1,
		6
	],
	direct: [
		1,
		2,
		3,
		4,
		5.2
	]
};
/** 32-bit NEC words for the Z-5500 deck. Address 0x10. */
var Z5500_IR = {
	power: "0x10EF58A7",
	volumeUp: "0x10EF708F",
	volumeDown: "0x10EFB04F",
	mute: "0x10EF30CF",
	input: "0x10EF20DF",
	effect: "0x10EF609F"
};
/** NEC carrier used by Android ConsumerIrManager. */
var NEC_CARRIER_HZ = 38e3;
var HEADER_MARK = 9e3;
var HEADER_SPACE = 4500;
var BIT_MARK = 560;
var ZERO_SPACE = 560;
var ONE_SPACE = 1690;
var STOP_MARK = 560;
/**
* Convert a 32-bit NEC word (address, ~address, command, ~command) into the
* raw timing pattern ConsumerIrManager.transmit expects at 38 kHz.
* Bytes go out high-byte first; bits within a byte go out LSB first.
*/
function encodeNec(hexString) {
	const hex = normalizeHex(hexString);
	const value = Number.parseInt(hex, 16);
	const pattern = [HEADER_MARK, HEADER_SPACE];
	for (let byteIndex = 3; byteIndex >= 0; byteIndex -= 1) {
		const byte = value >> byteIndex * 8 & 255;
		for (let bit = 0; bit < 8; bit += 1) {
			pattern.push(BIT_MARK);
			pattern.push(byte >> bit & 1 ? ONE_SPACE : ZERO_SPACE);
		}
	}
	pattern.push(STOP_MARK);
	return {
		hex: `0x${hex}`,
		frequencyHz: NEC_CARRIER_HZ,
		pattern
	};
}
function normalizeHex(hexString) {
	const body = hexString.trim().replace(/^0x/i, "");
	if (!/^[0-9a-fA-F]{1,8}$/.test(body)) throw new Error(`Not a 32-bit NEC code: ${hexString}`);
	return body.padStart(8, "0").toUpperCase();
}
function nativeBlaster() {
	const candidate = globalThis.NativeModules?.IRBlasterModule;
	if (!candidate || typeof candidate.transmitIRCode !== "function") return null;
	return candidate;
}
/**
* JS entry the deck calls. On Android this hits IRBlasterModule.transmitIRCode,
* which drives ConsumerIrManager. A browser has no emitter, so the same 38 kHz
* pattern is still built and reported as a preview burst.
*/
async function transmitIRCode(hexString) {
	const burst = encodeNec(hexString);
	const native = nativeBlaster();
	if (!native) return {
		...burst,
		transport: "preview"
	};
	await native.transmitIRCode(hexString);
	return {
		...burst,
		transport: "ir-blaster"
	};
}
var VIEW_W = 800;
var VIEW_H = 176;
function Waveform({ power, muted, volume, effectId, txPulse }) {
	const glowRef = (0, import_react.useRef)(null);
	const coreRef = (0, import_react.useRef)(null);
	const stateRef = (0, import_react.useRef)({
		power,
		muted,
		volume,
		effectId,
		txFrames: 0
	});
	stateRef.current = {
		power,
		muted,
		volume,
		effectId,
		txFrames: stateRef.current.txFrames
	};
	(0, import_react.useEffect)(() => {
		stateRef.current.txFrames = 18;
	}, [txPulse]);
	(0, import_react.useEffect)(() => {
		const media = window.matchMedia("(prefers-reduced-motion: reduce)");
		let frame = 0;
		let raf = 0;
		let stopped = false;
		const draw = () => {
			const { power: on, muted: isMuted, volume: level, effectId: effect, txFrames } = stateRef.current;
			const partials = WAVE_PARTIALS[effect];
			const mid = VIEW_H * .38;
			const amp = on ? (isMuted ? .035 : .08 + level / 40 * .32) * VIEW_H : 0;
			const tx = txFrames / 18;
			let d = "";
			for (let x = 0; x <= VIEW_W; x += 4) {
				const u = x / VIEW_W;
				let y = 0;
				if (on) {
					for (let k = 0; k < partials.length; k += 1) {
						const partial = partials[k] ?? 1;
						y += Math.sin(u * Math.PI * 2 * partial * 1.35 + frame * (.045 + k * .012)) / partials.length;
					}
					if (tx > 0) y += Math.sin(u * 70 + frame * .8) * tx * .55;
				}
				const py = mid + y * amp;
				d += `${x === 0 ? "M" : "L"}${x.toFixed(1)} ${py.toFixed(1)}`;
			}
			glowRef.current?.setAttribute("d", d);
			coreRef.current?.setAttribute("d", d);
			if (stateRef.current.txFrames > 0) stateRef.current.txFrames -= 1;
			if (!media.matches) frame += 1;
		};
		const loop = () => {
			draw();
			if (!stopped) raf = window.requestAnimationFrame(loop);
		};
		loop();
		return () => {
			stopped = true;
			window.cancelAnimationFrame(raf);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "wave",
		viewBox: `0 0 ${VIEW_W} ${VIEW_H}`,
		preserveAspectRatio: "none",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				className: "wave-grid",
				children: [[
					1,
					2,
					3,
					4,
					5,
					6,
					7
				].map((index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: VIEW_W / 8 * index,
					y1: "0",
					x2: VIEW_W / 8 * index,
					y2: VIEW_H
				}, `c${index}`)), [
					1,
					2,
					3
				].map((index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "0",
					y1: VIEW_H / 4 * index,
					x2: VIEW_W,
					y2: VIEW_H / 4 * index
				}, `r${index}`))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				ref: glowRef,
				className: "wave-glow"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				ref: coreRef,
				className: "wave-core"
			})
		]
	});
}
var HOLD_MS = 170;
function Z5500Deck() {
	const [power, setPower] = (0, import_react.useState)(true);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [volume, setVolume] = (0, import_react.useState)(18);
	const [effectIndex, setEffectIndex] = (0, import_react.useState)(0);
	const [inputIndex, setInputIndex] = (0, import_react.useState)(0);
	const [link, setLink] = (0, import_react.useState)("IR 38 KHZ");
	const [hot, setHot] = (0, import_react.useState)(false);
	const [txPulse, setTxPulse] = (0, import_react.useState)(0);
	const volumeRef = (0, import_react.useRef)(volume);
	const mutedRef = (0, import_react.useRef)(muted);
	const holdRef = (0, import_react.useRef)(0);
	const txSerial = (0, import_react.useRef)(0);
	const mounted = (0, import_react.useRef)(true);
	volumeRef.current = volume;
	mutedRef.current = muted;
	const effect = EFFECTS[effectIndex] ?? EFFECTS[0];
	const input = INPUTS[inputIndex] ?? INPUTS[0];
	const lit = new Set(effect.channels);
	(0, import_react.useEffect)(() => {
		mounted.current = true;
		return () => {
			mounted.current = false;
			window.clearInterval(holdRef.current);
		};
	}, []);
	const blast = (0, import_react.useCallback)((hex) => {
		const serial = ++txSerial.current;
		setHot(true);
		setTxPulse((n) => n + 1);
		setLink(`TX ${hex.slice(2).toUpperCase()}`);
		window.setTimeout(() => {
			if (mounted.current && txSerial.current === serial) setHot(false);
		}, 160);
		transmitIRCode(hex).then(() => {
			window.setTimeout(() => {
				if (mounted.current && txSerial.current === serial) setLink("IR 38 KHZ");
			}, 760);
		}).catch(() => {
			if (mounted.current && txSerial.current === serial) setLink("NO EMITTER");
		});
	}, []);
	const changeVolume = (0, import_react.useCallback)((dir) => {
		const next = Math.min(40, Math.max(0, volumeRef.current + dir));
		volumeRef.current = next;
		setVolume(next);
		if (mutedRef.current) {
			mutedRef.current = false;
			setMuted(false);
		}
		blast(dir > 0 ? Z5500_IR.volumeUp : Z5500_IR.volumeDown);
	}, [blast]);
	const changeVolumeRef = (0, import_react.useRef)(changeVolume);
	changeVolumeRef.current = changeVolume;
	const stopHold = (0, import_react.useCallback)(() => {
		window.clearInterval(holdRef.current);
		holdRef.current = 0;
	}, []);
	const startHold = (0, import_react.useCallback)((dir) => {
		stopHold();
		changeVolumeRef.current(dir);
		holdRef.current = window.setInterval(() => changeVolumeRef.current(dir), HOLD_MS);
	}, [stopHold]);
	const onPower = (0, import_react.useCallback)(() => {
		setPower((on) => !on);
		blast(Z5500_IR.power);
	}, [blast]);
	const onMute = (0, import_react.useCallback)(() => {
		setMuted((value) => {
			mutedRef.current = !value;
			return !value;
		});
		blast(Z5500_IR.mute);
	}, [blast]);
	const onInput = (0, import_react.useCallback)(() => {
		setInputIndex((index) => (index + 1) % INPUTS.length);
		blast(Z5500_IR.input);
	}, [blast]);
	const onEffect = (0, import_react.useCallback)(() => {
		setEffectIndex((index) => (index + 1) % EFFECTS.length);
		blast(Z5500_IR.effect);
	}, [blast]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.metaKey || event.ctrlKey || event.altKey) return;
			if (event.key === "ArrowUp") {
				event.preventDefault();
				changeVolume(1);
			} else if (event.key === "ArrowDown") {
				event.preventDefault();
				changeVolume(-1);
			} else if (!event.repeat && event.key.toLowerCase() === "p") onPower();
			else if (!event.repeat && event.key.toLowerCase() === "m") onMute();
			else if (!event.repeat && event.key.toLowerCase() === "i") onInput();
			else if (!event.repeat && event.key.toLowerCase() === "e") onEffect();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		changeVolume,
		onEffect,
		onInput,
		onMute,
		onPower
	]);
	const level = volume / 40 * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "stage",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shell",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "deck",
				"data-on": power ? "true" : "false",
				"data-muted": muted ? "true" : "false",
				"aria-label": "Z-5500 deck",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "screw screw-a",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "screw screw-b",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "screw screw-c",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "screw screw-d",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "deck-top",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "power",
								"data-control": "power",
								"aria-pressed": power,
								onClick: onPower,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "power-led",
									"aria-hidden": true
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "power-label",
									children: "POWER"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "brand",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "brand-name",
									children: "Z-5500"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "brand-sub",
									children: "Digital deck"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `emitter${hot ? " is-hot" : ""}`,
								"aria-hidden": true,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "emitter-lens" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "emitter-label",
									children: "IR"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waveform, {
							power,
							muted,
							volume,
							effectId: effect.id,
							txPulse
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lcd",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "lcd-figure",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "lcd-number",
										children: muted ? "MUTE" : String(volume).padStart(2, "0")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "lcd-unit",
										children: muted ? "LEVEL HELD" : "LEVEL"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "lcd-meta",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: input.label }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: effect.label }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "channels",
											children: CHANNELS.map((channel) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: lit.has(channel) ? "is-lit" : void 0,
												children: channel
											}, channel))
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "lcd-status",
									"aria-live": "polite",
									children: link
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "controls",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "vol",
							style: { ["--level"]: String(level) },
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "vol-ticks",
									"aria-hidden": true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "vol-arc",
									"aria-hidden": true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "vol-hit vol-hit-up",
									"data-control": "volume-up",
									"aria-label": "Volume up",
									onPointerDown: (event) => {
										if (event.button !== 0) return;
										event.currentTarget.setPointerCapture(event.pointerId);
										startHold(1);
									},
									onPointerUp: stopHold,
									onPointerCancel: stopHold,
									onClick: (event) => {
										if (event.detail === 0) changeVolume(1);
									},
									children: "VOL +"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "vol-hit vol-hit-down",
									"data-control": "volume-down",
									"aria-label": "Volume down",
									onPointerDown: (event) => {
										if (event.button !== 0) return;
										event.currentTarget.setPointerCapture(event.pointerId);
										startHold(-1);
									},
									onPointerUp: stopHold,
									onPointerCancel: stopHold,
									onClick: (event) => {
										if (event.detail === 0) changeVolume(-1);
									},
									children: "VOL −"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "vol-hub",
									"aria-hidden": true,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "vol-figure",
										children: String(volume).padStart(2, "0")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "vol-caption",
										children: "LEVEL"
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "side",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "effect",
									"data-control": "effect",
									"aria-label": `Effect control, ${effect.label}`,
									style: { ["--notch"]: `${effectIndex / EFFECTS.length * 360}deg` },
									onClick: onEffect,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "effect-notch",
											"aria-hidden": true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "effect-kicker",
											children: "EFFECT"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "effect-name",
											children: effect.short
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "key",
									"data-control": "mute",
									"aria-pressed": muted,
									onClick: onMute,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "key-kicker",
										children: "MUTE"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "key",
									"data-control": "input",
									onClick: onInput,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "key-kicker",
										children: "INPUT"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "key-value",
										children: input.label
									})]
								})
							]
						})]
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "note",
			children: "Power, volume, mute, input, and effect each send their NEC code to the Android IR blaster. A browser can only arm the same 38 kHz burst — the emitter fires on a phone that has one."
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Z5500Deck, {});
}
//#endregion
export { Home as component };
